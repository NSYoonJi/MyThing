-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: j8b207.p.ssafy.io    Database: mything
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_profile`
--

DROP TABLE IF EXISTS `member_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_profile` (
  `member_profile_id` bigint NOT NULL AUTO_INCREMENT,
  `gender` varchar(255) DEFAULT NULL,
  `hate_incense` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `prefer_incense` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `kakao_id` bigint DEFAULT NULL,
  PRIMARY KEY (`member_profile_id`),
  KEY `FKlerby7odh4q80uj4p1en6upct` (`kakao_id`),
  CONSTRAINT `FKlerby7odh4q80uj4p1en6upct` FOREIGN KEY (`kakao_id`) REFERENCES `member` (`kakao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_profile`
--

LOCK TABLES `member_profile` WRITE;
/*!40000 ALTER TABLE `member_profile` DISABLE KEYS */;
INSERT INTO `member_profile` VALUES (6,'FEMALE','321','https://j8b207.p.ssafy.io/find-image/images/user_image/root.png','ddd','183,165','2023-03-27',2727198294),(7,'FEMALE','156,183,321','https://j8b207.p.ssafy.io/find-image/images/user_image/root.png','한은정','315,313,1,1333,157','1996-08-20',2737935904),(8,'MALE','61,73','https://b207bucket.s3.ap-northeast-2.amazonaws.com/92b10160-392b-4071-9d67-cad8f094a3e1-image%2038.png','윤쥐찍찍','17,75','2011-06-06',2736078137),(10,'FEMALE','','https://j8b207.p.ssafy.io/find-image/images/user_image/root.png','하이하이1','321,73','2136-02-17',2718700847),(12,'FEMALE','','https://b207bucket.s3.ap-northeast-2.amazonaws.com/39e3affd-bdc7-4021-a150-19e41299179c-%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C.jpg','향수master','77,78','2020-07-07',2716554386),(14,'MALE','62','https://b207bucket.s3.ap-northeast-2.amazonaws.com/885091a5-ed08-4191-bcb1-e7f73ee3bdcd-KakaoTalk_20230407_013604117.jpg','mything','77,78,10,94','1995-01-19',2736120519),(15,'MALE','65','https://b207bucket.s3.ap-northeast-2.amazonaws.com/061b0750-9689-4908-b0ee-be75e91b086f-CCDC84D7-69C5-4AAE-93FC-C27209F52852.jpg','ns윤지','77,78,105','1998-06-07',2738122600),(16,'MALE','73','https://j8b207.p.ssafy.io/find-image/images/user_image/root.png','jjh','61','1997-05-04',2738723318);
/*!40000 ALTER TABLE `member_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:12:09
