-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: j8b207.p.ssafy.io    Database: mything
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_like`
--

DROP TABLE IF EXISTS `member_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_like` (
  `member_like_id` bigint NOT NULL AUTO_INCREMENT,
  `member_like_image` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `kakao_id` bigint DEFAULT NULL,
  PRIMARY KEY (`member_like_id`),
  KEY `FKa4wngf5tfo83xd6hx58qy6axx` (`kakao_id`),
  CONSTRAINT `FKa4wngf5tfo83xd6hx58qy6axx` FOREIGN KEY (`kakao_id`) REFERENCES `member` (`kakao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_like`
--

LOCK TABLES `member_like` WRITE;
/*!40000 ALTER TABLE `member_like` DISABLE KEYS */;
INSERT INTO `member_like` VALUES (1,'none, , , 7, 3, , 5, 15, 16, 17, 18, , 2, , 26, ','2023-04-06 08:57:28',2736078137),(3,'none, , , 6, 1, 18, 21, 25, ','2023-04-06 15:52:14',2716554386),(4,'none, 2, 12, 11, 15, 13, 34, 35, ','2023-04-06 16:24:21',2718700847),(5,'none, 32, 31, 26, ','2023-04-06 17:06:40',2736120519),(6,'none, 1, 18, ','2023-04-07 01:47:01',2738122600);
/*!40000 ALTER TABLE `member_like` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:12:10
