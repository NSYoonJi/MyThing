-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: j8b207.p.ssafy.io    Database: mything
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `longevity` varchar(255) DEFAULT NULL,
  `preference` varchar(255) DEFAULT NULL,
  `season` varchar(255) DEFAULT NULL,
  `sillage` varchar(255) DEFAULT NULL,
  `kakao_id` bigint DEFAULT NULL,
  `perfume_id` bigint DEFAULT NULL,
  `review_image_id` bigint DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  KEY `FKrxmew14qfm4a8syiw9bqra2d6` (`kakao_id`),
  KEY `FKm04tf2g1l2ciaki0m96qqyan0` (`perfume_id`),
  KEY `FKqbv14yvot4b1w7dua0fijngul` (`review_image_id`),
  CONSTRAINT `FKm04tf2g1l2ciaki0m96qqyan0` FOREIGN KEY (`perfume_id`) REFERENCES `perfume` (`perfume_id`),
  CONSTRAINT `FKqbv14yvot4b1w7dua0fijngul` FOREIGN KEY (`review_image_id`) REFERENCES `review_image` (`review_image_id`),
  CONSTRAINT `FKrxmew14qfm4a8syiw9bqra2d6` FOREIGN KEY (`kakao_id`) REFERENCES `member` (`kakao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'MIDDLE','LIKE','spring,summer','NORMAL',2716554386,165,1),(2,'LONG','LIKE','spring,summer','NORMAL',2736078137,979,2),(3,'SHORT','OK','summer','STRONG',2736078137,1,3),(4,'LONG','OK','spring,fall','WEAK',2736078137,601,4),(5,'LONG','OK','summer,spring','NORMAL',2736078137,11,5),(6,'MIDDLE','OK','spring,fall','WEAK',2736078137,62,6),(7,'MIDDLE','HATE','spring,winter','STRONG',2736078137,39,7),(8,'MIDDLE','LIKE','spring,summer','NORMAL',2736078137,55,8),(9,'MIDDLE','OK','spring,fall,winter,summer','STRONG',2736078137,169,9),(10,'LONG','OK','summer,spring,fall,winter','STRONG',2736078137,169,10),(11,'MIDDLE','LIKE','summer','NORMAL',2718700847,979,11),(12,'LONG','LIKE','spring','STRONG',2718700847,979,12),(13,'LONG','LIKE','spring','STRONG',2718700847,979,13),(14,'LONG','LIKE','spring','STRONG',2718700847,979,14),(15,'SHORT','OK','spring','WEAK',2718700847,979,15),(16,'LONG','LIKE','summer,spring','NORMAL',2736078137,979,16),(17,'MIDDLE','OK','fall,winter','NORMAL',2736078137,979,17),(18,'LONG','OK','spring,fall','STRONG',2736078137,165,18),(19,'MIDDLE','OK','fall,winter','WEAK',2736078137,165,19),(20,'LONG','OK','summer,spring','NORMAL',2736078137,165,20),(21,'MIDDLE','LIKE','spring,fall','STRONG',2736120519,165,21),(22,'MIDDLE','OK','spring,winter','STRONG',2736120519,165,22),(23,'LONG','LIKE','spring,fall','STRONG',2736120519,165,23),(24,'LONG','OK','spring,summer','NORMAL',2716554386,165,24),(25,'LONG','OK','fall,winter','WEAK',2736120519,11,25),(26,'MIDDLE','LIKE','summer,spring','WEAK',2736078137,11,26),(27,'MIDDLE','LIKE','fall,winter','WEAK',2736120519,11,27),(28,'SHORT','LIKE','fall,winter,summer','STRONG',2736078137,11,28),(29,'MIDDLE','OK','winter','NORMAL',2736078137,11,29),(30,'MIDDLE','OK','fall,winter','NORMAL',2736120519,11,30),(31,'LONG','LIKE','summer,spring','STRONG',2736120519,979,31),(32,'MIDDLE','LIKE','summer,spring','NORMAL',2736120519,979,32),(33,'LONG','OK','summer,winter','NORMAL',2736120519,979,33),(34,'LONG','LIKE','winter,fall','STRONG',2718700847,11,34),(35,'LONG','LIKE','winter','STRONG',2718700847,11,35),(36,'LONG','LIKE','spring,winter','STRONG',2736120519,2238,36),(37,'LONG','OK','spring,summer','NORMAL',2736120519,165,37),(38,'LONG','OK','spring,summer','NORMAL',2718700847,165,38);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:12:06
