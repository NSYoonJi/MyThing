-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: j8b207.p.ssafy.io    Database: mything
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review_image`
--

DROP TABLE IF EXISTS `review_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_image` (
  `review_image_id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `like_cnt` bigint DEFAULT NULL,
  PRIMARY KEY (`review_image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_image`
--

LOCK TABLES `review_image` WRITE;
/*!40000 ALTER TABLE `review_image` DISABLE KEYS */;
INSERT INTO `review_image` VALUES (1,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/d0c6131a-85a3-4c66-b1df-94ce229334bf-image%2093.png',2),(2,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/1fd2b022-f6b9-45dd-9bd0-205910ae4c27-dev-jeans.png',2),(3,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/5cb663c1-def3-44fa-b095-b2f685673aaf-fruit.jpeg',0),(4,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/efad33cd-69e6-4b60-a84a-cdccf12dc378-Image%20Pasted%20at%202023-1-28%2017-31.png',0),(5,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/8d9f3cc1-61b2-4878-9a29-7fba0d1ce1e4-image-jury-select.png',1),(6,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/36f07600-b05d-40e3-8ff1-593aca2bd5e3-image-game-board.png',0),(7,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/b84ab8ea-511c-4ae8-ba16-6ea5111a3c5e-dev-jeans.png',0),(8,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/95a6e0d0-40bf-4b03-8f45-69bcc12941f1-dev-jeans.png',0),(9,NULL,0),(10,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/201a7f16-b18a-4ead-9fd7-9c944c2e5706-dev-jeans.png',0),(11,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/228e99a3-422e-4d5c-9465-8e32531f6e86-%ED%9D%B0%EA%BD%83.jpg',1),(12,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/7d96d7f4-83b0-44a7-8034-94226e7f67d6-%EB%B6%84%ED%99%8D%EA%BD%83.jpg',1),(13,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/c44f4e92-06e0-41af-8ccd-4967e68c3d25-%ED%9D%B0%EA%BD%83.jpg',1),(14,NULL,0),(15,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/a4674a42-cff8-49b9-be51-e14a3e741bf9-%ED%9D%B0%EA%BD%83.jpg',2),(16,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/5f9d374b-ed3e-4ffd-a677-371806117bf0-oil.jpg',1),(17,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/c72e800a-16e5-4a9d-8700-fb194345f7be-oil2.jpeg',1),(18,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/bdd27b83-c382-4358-a1ac-0b709fe0f0da-dev-jeans.png',3),(19,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/692f11c9-b622-43c5-acc1-b3ed2aa83168-fruit.jpeg',0),(20,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/26ae2ffa-e3e7-4ab7-9142-1b4803d9a644-oil2.jpeg',0),(21,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/6dd47507-eb06-4702-8724-98d92bca0d53-paulina-ponce-P4z15DCQ8-I-unsplash.jpg',1),(22,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/d31ffcf8-52f6-4961-8b61-3cdec227edeb-annie-spratt-fxbzT96KzOo-unsplash.jpg',1),(23,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/ea08a959-5441-4f7a-8d5f-7739e550a9d3-yulia-mostova-a-yTvCSeLIw-unsplash.jpg',0),(24,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/838b94df-7fc3-462a-94fd-c5615edc065b-image%2093.png',0),(25,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/6208f0e9-e5e1-4192-bb5a-6fbc3754ed62-tijana-drndarski-j2ImpvUCstE-unsplash.jpg',1),(26,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/d24d1d3e-ac2b-4e39-83c4-72d250ab5d72-1.avif',2),(27,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/19a8238d-9b96-40f6-9821-9ade6b125c1c-marc-wieland-U9YrT6trizs-unsplash.jpg',0),(28,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/940bf61f-a724-47ec-9eaa-c7cb85db47de-2.jpeg',0),(29,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/0d6359c5-5c77-4619-abf4-142927d50b8b-images.jpeg',0),(30,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/169905b4-ec5e-4e48-a939-f9731e57525f-jeybi-esguerra-IapiMK-Wyps-unsplash.jpg',0),(31,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/7fc6f3ce-6227-4289-8009-5e7d2c5ac2e2-shifaaz-shamoon-okVXy9tG3KY-unsplash.jpg',1),(32,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/5612d266-33f4-4428-aee4-49cfcb87b593-roland-denes-beprhhF780E-unsplash.jpg',1),(33,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/7c17dd16-d442-499e-919d-2cae16f50f15-rayia-soderberg-ezSFnAFi9hY-unsplash.jpg',0),(34,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/525bdb43-4474-4d67-80b3-77f06e7d336b-%EB%AF%B8%EB%9D%BC.jpg',1),(35,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/2b66b629-bb1f-41e4-b532-32763482bc15-%EB%AF%B8%EB%9D%BC%EC%84%B8.jpg',1),(36,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/ff868ed4-fd7e-47f3-9d3d-e237d0c374ed-phil-desforges-Nw8wbiDE3gU-unsplash.jpg',0),(37,NULL,0),(38,'https://b207bucket.s3.ap-northeast-2.amazonaws.com/62518487-195d-4ff3-9a6c-2016fabce868-DALL%C2%B7E%202023-03-03%2015.23.59%20-%20green%20sky%20.png',0);
/*!40000 ALTER TABLE `review_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-07 11:12:10
